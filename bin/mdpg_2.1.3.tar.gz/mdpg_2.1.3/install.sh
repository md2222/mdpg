#!/bin/bash


echo "Install MD Password Generator"
echo "These files will be created:"
echo "/usr/local/bin/mdpg"
echo "/usr/local/share/mdpg/mainWin.glade"
echo "/usr/share/applications/mdpg.desktop"
echo "/usr/share/pixmaps/mdpg.png"
echo ""

echo -n "continue? (y/n): "
 
read ans
 
if [ "$ans" = "y" ] 
then


mkdir -p -- "/usr/local/share/mdpg"
cp -i -- mdpg "/usr/local/bin/"
cp -i -- mainWin.glade "/usr/local/share/mdpg/"
cp -i -- mdpg.desktop "/usr/share/applications/"
cp -i -- mdpg.png "/usr/share/pixmaps/"


echo "done"
#read -p "Press [Enter] key to exit..."

else
echo "canceled"
fi


exit 0

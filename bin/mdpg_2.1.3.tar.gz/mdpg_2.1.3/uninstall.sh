#!/bin/bash


echo "Uninstall MD Password Generator"
echo "These files will be deleted:"
echo "/usr/local/bin/mdpg"
echo "/usr/local/share/mdpg/mainWin.glade"
echo "/usr/share/applications/mdpg.desktop"
echo "/usr/share/pixmaps/mdpg.png"
echo ""

echo -n "continue? (y/n): "
 
read ans
 
if [ "$ans" = "y" ] 
then


rm -- "/usr/local/bin/mdpg"
rm -r "/usr/local/share/mdpg"
rm -- "/usr/share/applications/mdpg.desktop"
rm -- "/usr/share/pixmaps/mdpg.png"


echo "done"
#read -p "Press [Enter] key to exit..."

else
echo "canceled"
fi


exit 0
